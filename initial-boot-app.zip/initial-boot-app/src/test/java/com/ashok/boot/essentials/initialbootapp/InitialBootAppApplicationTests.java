package com.ashok.boot.essentials.initialbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitialBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
